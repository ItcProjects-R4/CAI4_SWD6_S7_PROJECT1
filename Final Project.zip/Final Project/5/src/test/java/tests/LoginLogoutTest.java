package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginLogoutTest {
    WebDriver driver;
    LoginPage loginPage;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testLoginChangePasswordLogout() {
        // Step 1: Login with valid credentials
        loginPage.login("Admin", "admin123");

        // Step 2: Try to navigate to Change Password page
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/pim/changePassword");

        // Step 3: Check if change password fields exist
        boolean changePasswordAvailable = driver.findElements(By.id("currentPassword")).size() > 0;

        if (changePasswordAvailable) {
            driver.findElement(By.id("currentPassword")).sendKeys("admin123");
            driver.findElement(By.id("newPassword")).sendKeys("NewPass@123");
            driver.findElement(By.id("confirmPassword")).sendKeys("NewPass@123");
            driver.findElement(By.cssSelector("button[type='submit']")).click();

            String successMsg = driver.findElement(By.cssSelector(".oxd-toast-content")).getText();
            System.out.println("Password Change Message: " + successMsg);
            Assert.assertTrue(successMsg.contains("Successfully"), "Password change should succeed");
        } else {
            System.out.println("Change Password option not available in demo site — skipping step.");
        }

        // Step 4: Logout
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/logout");

        // Step 5: Verify redirected to login page
        Assert.assertTrue(driver.getCurrentUrl().contains("auth/login"),
                "User should be redirected to login page after logout");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
