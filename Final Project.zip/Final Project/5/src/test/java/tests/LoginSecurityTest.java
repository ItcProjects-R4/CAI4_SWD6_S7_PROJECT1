package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginSecurityTest{
    WebDriver driver;
    LoginPage loginPage;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        loginPage = new LoginPage(driver);
    }

    @Test(priority = 1)
    public void testSQLInjectionLogin() {
        String sqlPayload = "' OR '1'='1";

        loginPage.login(sqlPayload, sqlPayload);

        String actualError = loginPage.getErrorMessage();
        System.out.println("SQL Injection Error: " + actualError);

        Assert.assertTrue(actualError.contains("Invalid credentials"),
                "SQL Injection attempt should fail with 'Invalid credentials'");
    }

    @Test(priority = 2)
    public void testXSSAttemptLogin() {
        String xssPayload = "<script>alert('XSS')</script>";

        loginPage.login(xssPayload, "dummyPassword");

        String actualError = loginPage.getErrorMessage();
        System.out.println("XSS Attempt Error: " + actualError);

        Assert.assertTrue(actualError.contains("Invalid credentials"),
                "XSS attempt should fail with 'Invalid credentials'");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
