package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class ChangePasswordPage {
    WebDriver driver;
    WebDriverWait wait;

    // Locators (OrangeHRM demo has "Change Password" under My Info → Change Password)
    private By currentPasswordField = By.name("currentPassword");
    private By newPasswordField     = By.name("newPassword");
    private By confirmPasswordField = By.name("confirmPassword");
    private By saveButton           = By.cssSelector("button[type='submit']");
    private By successMessage       = By.cssSelector(".oxd-toast-content");

    public ChangePasswordPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void changePassword(String currentPwd, String newPwd) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(currentPasswordField)).sendKeys(currentPwd);
        driver.findElement(newPasswordField).sendKeys(newPwd);
        driver.findElement(confirmPasswordField).sendKeys(newPwd);
        driver.findElement(saveButton).click();
    }

    public String getSuccessMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(successMessage)).getText();
    }
}
