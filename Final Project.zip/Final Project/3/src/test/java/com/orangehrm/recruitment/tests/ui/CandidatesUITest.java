package com.orangehrm.recruitment.tests.ui;

import com.orangehrm.recruitment.pages.CandidatesPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Collections;

/**
 * UI Test Suite for the Recruitment Candidates module.
 * Focuses strictly on: Add Candidate, Search Candidate, and Delete Candidate.
 */
public class CandidatesUITest {
    private WebDriver driver;
    private CandidatesPage candidatesPage;

    // Test Data
    public static final String firstName = "Lobna";
    public static final String lastName = "Mohamed";
    public static final String email = "lobna.mohamed@gmail.com";
    public static final String contactNumber = "1234567890";
    public static final String vacancyName = "Associate QA Engineer"; // Change to match dynamic vacancy in OrangeHRM
    public static final String candidateFullName = firstName + " " + lastName;

    @BeforeMethod
    public void setUp() {
        // WebDriver initialization
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-gpu");
        options.addArguments("--disable-extensions");
        
        // Anti-bot detection bypass: hides navigator.webdriver to prevent session invalidation
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
        options.setExperimentalOption("useAutomationExtension", false);
        
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        // --- Authentication Strategy ---
        // Assume user is already authenticated - robust login helper
        performHelperLogin();

        candidatesPage = new CandidatesPage(driver);
    }

    /**
     * Helper to authenticate the session (since login module is implemented by another team member).
     */
    private void performHelperLogin() {
        int attempts = 3;
        for (int i = 0; i < attempts; i++) {
            try {
                driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
                
                // Wait for username input to be visible and interactable
                org.openqa.selenium.WebElement usernameInput = wait.until(
                        ExpectedConditions.elementToBeClickable(By.name("username")));
                usernameInput.clear();
                usernameInput.sendKeys("Admin");
                
                org.openqa.selenium.WebElement passwordInput = driver.findElement(By.name("password"));
                passwordInput.clear();
                passwordInput.sendKeys("admin123");
                
                driver.findElement(By.xpath("//button[@type='submit']")).click();
                
                // Wait until the URL changes to dashboard
                wait.until(ExpectedConditions.urlContains("/dashboard"));
                
                // Wait until the sidebar menu/dashboard sidepanel is visible to confirm login is completed
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("oxd-sidepanel")));
                
                // Let the SPA session context settle
                Thread.sleep(2000);
                return; // success!
            } catch (Exception e) {
                System.err.println("Session authentication helper attempt " + (i + 1) + " failed: " + e.getMessage());
                if (i == attempts - 1) {
                    throw new RuntimeException("Pre-authentication failed! Cannot proceed with UI tests.", e);
                }
                try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
            }
        }
    }

    @Test(priority = 1, description = "Verify that a candidate can be successfully added to the system")
    public void testAddCandidate() {
        candidatesPage.navigateToCandidatesPage();
        
        // Add candidate
        candidatesPage.addCandidate(firstName, lastName, email, contactNumber, vacancyName);
        
        // Verify candidate is listed in the candidate directory
        candidatesPage.searchCandidate(candidateFullName);
        boolean isListed = candidatesPage.isCandidateListed(candidateFullName);
        
        Assert.assertTrue(isListed, "Candidate should be listed in the candidates table after addition.");
    }

    @Test(priority = 2, description = "Verify that a candidate can be searched by name")
    public void testSearchCandidate() {
        candidatesPage.navigateToCandidatesPage();
        
        // Search for the candidate
        candidatesPage.searchCandidate(candidateFullName);
        boolean isListed = candidatesPage.isCandidateListed(candidateFullName);
        
        Assert.assertTrue(isListed, "Search result should find and list the candidate: " + candidateFullName);
    }

    @Test(priority = 3, description = "Verify that a candidate can be deleted from the system")
    public void testDeleteCandidate() {
        candidatesPage.navigateToCandidatesPage();
        
        // Delete all instances of this candidate to ensure database is clean and verification passes
        int deletedCount = 0;
        while (true) {
            candidatesPage.searchCandidate(candidateFullName);
            if (candidatesPage.isCandidateListed(candidateFullName)) {
                candidatesPage.deleteCandidate(candidateFullName);
                deletedCount++;
            } else {
                break;
            }
        }
        
        Assert.assertTrue(deletedCount > 0, "At least one candidate should have been deleted.");
        
        // Verify candidate is no longer listed in the candidate directory
        candidatesPage.searchCandidate(candidateFullName);
        boolean isListed = candidatesPage.isCandidateListed(candidateFullName);
        
        Assert.assertFalse(isListed, "Candidate should be removed from the candidates table after deletion.");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
