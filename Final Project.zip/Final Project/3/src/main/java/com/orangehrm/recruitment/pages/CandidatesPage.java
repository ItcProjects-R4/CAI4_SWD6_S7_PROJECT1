package com.orangehrm.recruitment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Page Object Class representing the Recruitment Candidates Page in OrangeHRM.
 * Relies on a pre-authenticated WebDriver session.
 */
public class CandidatesPage {
    private final WebDriver driver;
    private final WebDriverWait wait;
    private final String baseUrl = "https://opensource-demo.orangehrmlive.com";

    // --- Locators ---
    
    // Top-level / Navigation locators
    private final By recruitmentMenuLink = By.xpath("//a[contains(@href, 'recruitment')]");
    
    // Candidates List Page Locators
    private final By addButton = By.xpath("//button[contains(@class, 'oxd-button') and .//i[contains(@class, 'bi-plus')]]");
    private final By searchButton = By.xpath("//button[@type='submit']");
    private final By candidateNameSearchInput = By.xpath("//input[@placeholder='Type for hints...']");
    private final By candidateAutocompleteOption = By.xpath("//div[contains(@class, 'oxd-autocomplete-option')]");
    private final By tableRows = By.className("oxd-table-card");
    private final By candidateNamesInTable = By.xpath("//div[@role='row']/div[3]");
    
    // Add Candidate Form Locators
    private final By firstNameInput = By.name("firstName");
    private final By middleNameInput = By.name("middleName");
    private final By lastNameInput = By.name("lastName");
    private final By vacancyDropdown = By.className("oxd-select-text");
    private final By vacancyDropdownOptions = By.xpath("//div[contains(@class, 'oxd-select-dropdown')]//div[@role='option']");
    private final By emailInput = By.xpath("//label[contains(., 'Email')]/parent::div/following-sibling::div/input");
    private final By contactNumberInput = By.xpath("//label[contains(., 'Contact Number')]/parent::div/following-sibling::div/input");
    private final By consentCheckbox = By.className("oxd-checkbox-wrapper");
    private final By saveButton = By.xpath("//button[@type='submit' and contains(., 'Save')]");
    
    // Delete Candidate Locators
    private final By deleteIconByCandidateName = By.xpath(".//button[contains(@class, 'oxd-icon-button')]/i[contains(@class, 'bi-trash')]/parent::button");
    private final By confirmDeleteButton = By.xpath("//button[contains(@class, 'oxd-button--label-danger')]");
 
    public CandidatesPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    /**
     * Navigates directly to the Candidates page.
     */
    public void navigateToCandidatesPage() {
        try {
            // Try clicking the sidebar Recruitment link to navigate within the SPA (avoids session drops)
            WebElement menuLink = wait.until(ExpectedConditions.elementToBeClickable(recruitmentMenuLink));
            menuLink.click();
        } catch (Exception e) {
            // Fallback to direct URL navigation if side menu is not present or interactable
            driver.get(baseUrl + "/web/index.php/recruitment/viewCandidates");
        }
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(addButton));
        } catch (Exception e) {
            throw new RuntimeException("NAVIGATION FAILURE! Current URL: " + driver.getCurrentUrl(), e);
        }
    }

    /**
     * Navigates via side menu click (alternative way).
     */
    public void navigateViaMenu() {
        wait.until(ExpectedConditions.elementToBeClickable(recruitmentMenuLink)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(addButton));
    }

    /**
     * Clicks on the 'Add' candidate button to open the form.
     */
    public void clickAddButton() {
        wait.until(ExpectedConditions.elementToBeClickable(addButton)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameInput));
    }

    /**
     * Fills out the Add Candidate form and saves it.
     */
    public void addCandidate(String firstName, String lastName, String email, String contactNumber, String vacancy) {
        clickAddButton();

        driver.findElement(firstNameInput).sendKeys(firstName);
        driver.findElement(lastNameInput).sendKeys(lastName);
        
        // Select vacancy if provided
        if (vacancy != null && !vacancy.isEmpty()) {
            safeClick(driver.findElement(vacancyDropdown));
            List<WebElement> options = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(vacancyDropdownOptions));
            for (WebElement option : options) {
                if (option.getText().trim().equalsIgnoreCase(vacancy)) {
                    org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
                    js.executeScript("arguments[0].scrollIntoView(true);", option);
                    try { Thread.sleep(200); } catch (InterruptedException ignored) {}
                    safeClick(option);
                    break;
                }
            }
        }

        driver.findElement(emailInput).sendKeys(email);
        driver.findElement(contactNumberInput).sendKeys(contactNumber);
        
        // Consent checkbox if visible
        try {
            driver.findElement(consentCheckbox).click();
        } catch (Exception e) {
            // Optional checkbox
        }

        driver.findElement(saveButton).click();
        
        // Wait for page to reload/redirect to Candidate Profile detail view or listing view
        try {
            Thread.sleep(4000); // 4 seconds delay to ensure database write is completed and page state updates
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Performs a candidate search using the candidate's first and last name.
     */
    public void searchCandidate(String candidateFullName) {
        navigateToCandidatesPage();
        
        WebElement nameInput = wait.until(ExpectedConditions.elementToBeClickable(candidateNameSearchInput));
        String val = nameInput.getAttribute("value");
        if (val != null && !val.isEmpty()) {
            nameInput.sendKeys(Keys.CONTROL + "a");
            nameInput.sendKeys(Keys.BACK_SPACE);
        }
        nameInput.sendKeys(candidateFullName);
        
        // Wait for search autocomplete hints to show, filtering out "Searching..."
        long endTime = System.currentTimeMillis() + 6000;
        WebElement targetOption = null;
        String optionText = "";
        while (System.currentTimeMillis() < endTime) {
            try {
                List<WebElement> options = driver.findElements(candidateAutocompleteOption);
                if (!options.isEmpty()) {
                    WebElement firstOption = options.get(0);
                    String firstText = firstOption.getText().trim();
                    if (!firstText.toLowerCase().contains("searching")) {
                        targetOption = firstOption;
                        optionText = firstText;
                        break;
                    }
                }
            } catch (Exception ignored) {}
            try { Thread.sleep(250); } catch (InterruptedException ignored) {}
        }

        if (targetOption != null && (optionText.toLowerCase().contains("no results") || optionText.toLowerCase().contains("no records"))) {
            // The candidate does not exist. Clear the input to avoid "Invalid" validation error
            nameInput.sendKeys(Keys.CONTROL + "a");
            nameInput.sendKeys(Keys.BACK_SPACE);
            nameInput.sendKeys(Keys.ESCAPE);
            driver.findElement(searchButton).click();
            try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
            return;
        }

        if (targetOption != null && !optionText.isEmpty()) {
            org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", targetOption);
            driver.findElement(searchButton).click();
            try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
        } else {
            nameInput.sendKeys(Keys.ESCAPE);
            driver.findElement(searchButton).click();
            try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
        }
    }

    /**
     * Verifies if a candidate is present in the table.
     */
    public boolean isCandidateListed(String candidateFullName) {
        List<WebElement> rows = driver.findElements(tableRows);
        for (WebElement row : rows) {
            if (row.getText().toLowerCase().contains(candidateFullName.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Deletes a candidate by name.
     */
    public void deleteCandidate(String candidateFullName) {
        // Find the specific row containing the candidate
        List<WebElement> rows = driver.findElements(tableRows);
        for (WebElement row : rows) {
            if (row.getText().toLowerCase().contains(candidateFullName.toLowerCase())) {
                 WebElement deleteBtn = row.findElement(deleteIconByCandidateName);
                 org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
                 js.executeScript("arguments[0].click();", deleteBtn);
                 
                 // Confirm deletion in modal dialog
                 WebElement confirmBtn = wait.until(ExpectedConditions.presenceOfElementLocated(confirmDeleteButton));
                 js.executeScript("arguments[0].click();", confirmBtn);
                 
                 // Wait for the modal/overlay to disappear
                 wait.until(ExpectedConditions.invisibilityOfElementLocated(confirmDeleteButton));
                
                // Wait for the server-side deletion transaction to commit
                try {
                    Thread.sleep(4000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                return;
            }
        }
        throw new RuntimeException("Candidate " + candidateFullName + " not found to delete.");
    }
 
    private void safeClick(WebElement element) {
        try {
            element.click();
        } catch (Exception e) {
            org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
        }
    }
}
