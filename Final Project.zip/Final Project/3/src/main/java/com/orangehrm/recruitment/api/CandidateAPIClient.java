package com.orangehrm.recruitment.api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.List;
import java.util.Map;

/**
 * API Client Class for managing Recruitment Candidates using Rest Assured.
 * Focuses on candidate creation, retrieval, and deletion.
 */
public class CandidateAPIClient {
    private final String baseUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/recruitment/candidates";
    private final RequestSpecification requestSpec;

    /**
     * Constructor accepting a pre-authenticated RequestSpecification (e.g., carrying session cookies/tokens).
     *
     * @param authenticatedSpec pre-configured RequestSpecification from the auth module.
     */
    public CandidateAPIClient(RequestSpecification authenticatedSpec) {
        this.requestSpec = RestAssured.given()
                .spec(authenticatedSpec)
                .baseUri(baseUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Referer", "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewCandidates")
                .contentType(ContentType.JSON);
    }

    /**
     * Alternative constructor that sets up base configuration and accepts multiple session cookies.
     *
     * @param sessionCookies map of all session cookies from browser
     */
    public CandidateAPIClient(Map<String, String> sessionCookies) {
        this.requestSpec = RestAssured.given()
                .baseUri(baseUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Referer", "https://opensource-demo.orangehrmlive.com/web/index.php/recruitment/viewCandidates")
                .cookies(sessionCookies)
                .contentType(ContentType.JSON);
    }

    /**
     * Send a POST request to create a candidate.
     */
    public Response createCandidate(Map<String, Object> payload) {
        return RestAssured.given()
                .spec(requestSpec)
                .body(payload)
                .when()
                .post("");
    }

    /**
     * Send a GET request to retrieve candidates.
     */
    public Response getCandidates(Map<String, Object> queryParams) {
        RequestSpecification spec = RestAssured.given().spec(requestSpec);
        if (queryParams != null) {
            spec.queryParams(queryParams);
        }
        return spec.when()
                .get("");
    }

    /**
     * Send a DELETE request to remove candidates by list of IDs.
     */
    public Response deleteCandidates(List<Integer> ids) {
        Map<String, Object> payload = Map.of("ids", ids);
        return RestAssured.given()
                .spec(requestSpec)
                .body(payload)
                .when()
                .delete("");
    }
}
