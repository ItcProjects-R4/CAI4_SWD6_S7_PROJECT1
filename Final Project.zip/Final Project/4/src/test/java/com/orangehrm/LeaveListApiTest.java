package com.orangehrm;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static io.restassured.RestAssured.given;

public class LeaveListApiTest {

    private static final String BASE_URL = "https://opensource-demo.orangehrmlive.com";
    private static final String LOGIN_PAGE_PATH = "/web/index.php/auth/login";
    private static final String LEAVE_LIST_ENDPOINT = "/web/index.php/api/v2/leave/leaves";

    private static final String USERNAME = "Admin";
    private static final String PASSWORD = "admin123";

    private static final Pattern CSRF_TOKEN_PATTERN =
            Pattern.compile("name=\"_token\"\\s+value=\"([^\"]+)\"");

    private Map<String, String> authenticatedCookies;

    @BeforeClass
    public void authenticate() {
        RestAssured.baseURI = BASE_URL;

        Response loginPageResponse = given()
                .relaxedHTTPSValidation()
                .when()
                .get(LOGIN_PAGE_PATH)
                .then()
                .statusCode(200)
                .extract()
                .response();

        String csrfToken = extractCsrfToken(loginPageResponse.getBody().asString());
        Assert.assertNotNull(csrfToken, "Unable to extract CSRF token from the login page.");

        Map<String, String> initialCookies = loginPageResponse.getCookies();


        Response loginResponse = given()
                .relaxedHTTPSValidation()
                .cookies(initialCookies)
                .contentType("application/x-www-form-urlencoded")
                .formParam("_token", csrfToken)
                .formParam("username", USERNAME)
                .formParam("password", PASSWORD)
                .redirects().follow(true)
                .when()
                .post(LOGIN_PAGE_PATH)
                .then()
                .extract()
                .response();


        authenticatedCookies = new java.util.HashMap<>(initialCookies);
        authenticatedCookies.putAll(loginResponse.getCookies());

        Assert.assertTrue(
                authenticatedCookies.containsKey("orangehrm"),
                "Authenticated session cookie 'orangehrm' was not found after login."
        );
    }

    @Test(description = "Verify the Leave List API endpoint returns HTTP 200 OK for an authenticated session")
    public void verifyLeaveListApiReturnsOk() {

        String fromDate = LocalDate.now().withDayOfYear(1).toString();
        String toDate = LocalDate.now().withMonth(12).withDayOfMonth(31).toString();

        RequestSpecification request = given()
                .relaxedHTTPSValidation()
                .cookies(authenticatedCookies)
                .header("X-Requested-With", "XMLHttpRequest")
                .queryParam("fromDate", fromDate)
                .queryParam("toDate", toDate)
                .queryParam("limit", 50)
                .queryParam("offset", 0);

        Response response = request
                .when()
                .get(LEAVE_LIST_ENDPOINT)
                .then()
                .extract()
                .response();

        Assert.assertEquals(
                response.getStatusCode(),
                200,
                "Expected HTTP 200 OK from Leave List API but got " + response.getStatusCode()
                        + ". Response body: " + response.getBody().asString()
        );

        response.then().statusCode(200);
        response.then().contentType(org.hamcrest.Matchers.containsString("application/json"));

        Assert.assertNotNull(response.getBody(), "Leave List API response body should not be null.");
        Assert.assertTrue(
                response.getBody().asString().contains("data"),
                "Expected Leave List API response to contain a 'data' field."
        );
    }


    private String extractCsrfToken(String htmlBody) {
        Matcher matcher = CSRF_TOKEN_PATTERN.matcher(htmlBody);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }
}