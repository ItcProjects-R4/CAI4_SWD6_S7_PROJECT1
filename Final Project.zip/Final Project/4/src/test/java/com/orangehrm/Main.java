package com.orangehrm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class Main {

    private WebDriver driver;
    private WebDriverWait wait;

    private static final String BASE_URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
    private static final String LEAVE_LIST_URL = "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveList";
    private static final String USERNAME = "Admin";
    private static final String PASSWORD = "admin123";

    private static final By USERNAME_FIELD = By.name("username");
    private static final By PASSWORD_FIELD = By.name("password");
    private static final By LOGIN_FORM = By.cssSelector("form.oxd-form");
    private static final By DASHBOARD_HEADER = By.cssSelector("h6.oxd-topbar-header-breadcrumb-module");
    private static final By LEAVE_MENU_LINK = By.xpath("//span[@class='oxd-main-menu-item--name' and text()='Leave']");
    private static final By LEAVE_LIST_SUBMENU_LINK = By.xpath("//a[normalize-space(text())='Leave List']");
    private static final By PAGE_HEADER = By.cssSelector("h6.oxd-text--h6.oxd-topbar-header-breadcrumb-module");

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--start-maximized");

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @Test(description = "Verify that a logged-in user can navigate to the Leave List page and the page header is correct")
    public void verifyLeaveListPageHeader() {

        driver.get(BASE_URL);

        wait.until(ExpectedConditions.visibilityOfElementLocated(LOGIN_FORM));

        WebElement usernameInput = driver.findElement(USERNAME_FIELD);
        usernameInput.clear();
        usernameInput.sendKeys(USERNAME);

        WebElement passwordInput = driver.findElement(PASSWORD_FIELD);
        passwordInput.clear();
        passwordInput.sendKeys(PASSWORD);

        passwordInput.submit();

        WebElement dashboardHeader = wait.until(
                ExpectedConditions.visibilityOfElementLocated(DASHBOARD_HEADER)
        );
        Assert.assertTrue(dashboardHeader.isDisplayed(), "Dashboard header was not displayed after login.");

        WebElement leaveMenu = wait.until(ExpectedConditions.elementToBeClickable(LEAVE_MENU_LINK));
        leaveMenu.click();

        WebElement leaveListSubMenu = wait.until(ExpectedConditions.elementToBeClickable(LEAVE_LIST_SUBMENU_LINK));
        leaveListSubMenu.click();

        WebElement pageHeader = wait.until(
                ExpectedConditions.visibilityOfElementLocated(PAGE_HEADER)
        );

        String actualHeaderText = pageHeader.getText().trim();

        Assert.assertNotNull(actualHeaderText, "Page header text should not be null.");
        Assert.assertFalse(actualHeaderText.isEmpty(), "Page header text should not be empty.");
        Assert.assertTrue(
                actualHeaderText.contains("Leave List"),
                "Expected page header to contain 'Leave List' but found: '" + actualHeaderText + "'"
        );
        Assert.assertEquals(
                driver.getCurrentUrl(),
                LEAVE_LIST_URL,
                "Browser did not navigate to the expected Leave List URL."
        );
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}