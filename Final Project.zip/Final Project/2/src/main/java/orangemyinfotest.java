package dev.selenium.hello;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class orangemyinfotest {
    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        // open the website and ogin
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username"))).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        // move to my info
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Info']"))).click();

        // wait until middle name is clickable
        WebElement middleNameField = wait.until(ExpectedConditions.elementToBeClickable(By.name("middleName")));

        // click when ready
        middleNameField.click();

        // clear
        middleNameField.clear();

        // clear by loop
        for (int i = 0; i < 3; i++) {
            middleNameField.sendKeys(org.openqa.selenium.Keys.CONTROL + "a");
            middleNameField.sendKeys(org.openqa.selenium.Keys.DELETE);
            middleNameField.sendKeys(org.openqa.selenium.Keys.BACK_SPACE);
        }

        // the new name
        middleNameField.sendKeys("logeen");

        // select save button
        WebElement saveButton = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//h6[text()='Personal Details']/following::button[@type='submit'][1]")
        ));

        // save by javascript to make sure there is n mistakes
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", saveButton);

        // refresh
        Thread.sleep(4000);
        driver.navigate().refresh();

        // chick after refresh
        Thread.sleep(5000);
        driver.quit();
    }
}