package dev.selenium.hello;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class orangenationalityapi {
    public static void main(String[] args) {

        // Set the Base URL for the OrangeHRM API
        RestAssured.baseURI = "https://opensource-demo.orangehrmlive.com/web/index.php/api/v2";
        // Send GET request to fetch all nationalities from the server
        Response response = RestAssured.given()
                .header("Cookie", "orangehrm=sv9epqs6igtlmkcfujqpq9nruf")
                .when()
                .get("/admin/nationalities");

        // Get and print the HTTP Status Code
        int statusCode = response.getStatusCode();
        System.out.println("Status Code for nationalities list is: " + statusCode);

        // Get the response body as a string
        String responseBody = response.getBody().asString();

        // If the request is successful, print the first 200 characters of the data
        if (statusCode == 200 && !responseBody.isEmpty()) {
            System.out.println("Part of the received nationalities list: " + responseBody.substring(0, 200) + "...");
        } else {
            System.out.println("No data received. Server response: " + responseBody);
        }
    }
}