package dev.selenium.hello;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class orangeapitest {
    public static void main(String[] args) {

        // server url
        RestAssured.baseURI = "https://opensource-demo.orangehrmlive.com/web/index.php/api/v2";

        // get personal details
        Response response = RestAssured.given()
                .header("Cookie", "orangehrm=bkoi341opsgnkb00mtrh14jsfh")
                .when()
                .get("/pim/employees/7/personal-details");

        // status code
        int statusCode = response.getStatusCode();
        System.out.println("status code is " + statusCode);

        // print response body
        String responseBody = response.getBody().asString();
        System.out.println("details is " + responseBody);
    }
}
