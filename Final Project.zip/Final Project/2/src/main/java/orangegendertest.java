package dev.selenium.hello;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class orangegendertest {
    public static void main(String[] args) throws InterruptedException {

        // open chrom
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        // open the website and login
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username"))).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        // open my info
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Info']"))).click();

        // wait 2 sec until its ready
        Thread.sleep(2000);

        // click female
        WebElement femaleLabel = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//label[text()='Female']")
        ));
        femaleLabel.click();

        // click on save
        WebElement saveButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//h6[text()='Personal Details']/following::button[@type='submit'][1]")
        ));
        saveButton.click();

        // wait 2 sec until its saved
        Thread.sleep(2000);

        // refresh
        driver.navigate().refresh();

        // watch the result
        Thread.sleep(3000);

        // close
        driver.quit();
    }
}