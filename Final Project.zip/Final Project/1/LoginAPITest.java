package com.orangehrm.recruitment.tests.api;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginAPITest {

    @Test
    public void loginAPI() {

        Response response =
                RestAssured
                        .given()
                        .contentType("application/x-www-form-urlencoded")
                        .formParam("username", "Admin")
                        .formParam("password", "admin123")
                        .when()
                        .post("https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate");

        System.out.println(response.asString());

        Assert.assertEquals(response.getStatusCode(), 200);

    }
}
