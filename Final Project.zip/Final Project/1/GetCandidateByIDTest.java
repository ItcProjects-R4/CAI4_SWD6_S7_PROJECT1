package com.orangehrm.recruitment.tests.api;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GetCandidateByIDTest {

    @Test
    public void getCandidateByID() {

        String candidateID = "1";

        Response response =
                RestAssured
                        .given()
                        .header("Accept", "application/json")
                        .when()
                        .get("https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/recruitment/candidates/" + candidateID);

        System.out.println(response.asString());

        Assert.assertEquals(response.getStatusCode(), 200);

    }
}
