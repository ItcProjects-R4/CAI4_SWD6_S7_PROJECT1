import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LogoutTest {

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();

        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        driver.manage().window().maximize();

        Thread.sleep(3000);

        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        Thread.sleep(3000);

        driver.findElement(By.className("oxd-userdropdown-tab")).click();

        Thread.sleep(2000);

        driver.findElement(By.linkText("Logout")).click();

        Thread.sleep(3000);

        if (driver.getCurrentUrl().contains("login")) {
            System.out.println("Logout Passed");
        } else {
            System.out.println("Logout Failed");
        }

        driver.quit();
    }
}